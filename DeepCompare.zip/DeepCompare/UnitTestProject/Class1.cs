﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DeepCompare;
using DeepCompare.Interface;

namespace UnitTestProject
{
    [TestClass]
    public class Class1
    {
        // test data
        int[] a = { 1, 2, 3 };
        int[] b = { 2,1,3};
        int[] c = { 2, 1,4, 3 };
        //============================
        public static ICompare compare;
        public Class1()
        {
        
          
        }
        //
        [TestMethod]
        public void arrayEqualcomparertest()
        {


         bool result=   compare.isarrayequal(a, b);

            Assert.IsTrue(result);
        }

        [TestMethod]
        public void arrayNotEqualcomparertest()
        {


            bool result = compare.isarrayequal(a, c);

            Assert.IsFalse(result);
        }

        [TestMethod]
        public void NotEqualcomparertest()
        {
            Student vijay = new Student();
            vijay.name = "vijay";
            vijay.marks = new[] { 80, 90, 10 };
            Student ajay = new Student();
            ajay.name = "ajay";
            ajay.marks = new[] { 80, 90, 10 };

            bool result = compare.equalcomparere(ajay, vijay);

            Assert.IsFalse(result);
        }
        [TestMethod]
        public void Equalcomparertest()
        {
            Student ajay = new Student();
            ajay.name = "ajay";
            ajay.marks = new[] { 80, 90, 10 };
            Student ajayduplicate = new Student();
            ajayduplicate.name = "ajay";
            ajayduplicate.marks = new[] { 80, 90, 10 };

            bool result = compare.equalcomparere(ajayduplicate, ajayduplicate);

            Assert.IsTrue(result);
        }
    }
   public class Student
    {
        public string name { get; set; }
        public int[] marks { get; set; }
    }
}
