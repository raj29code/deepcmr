﻿using DeepCompare.Interface;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeepCompare
{
   public class Comparator : ICompare
    {
      
        public bool equalcomparere(object object1, object Object2)
        {

      
            if (object.ReferenceEquals(Object2, null))
                return false;
            if (object.ReferenceEquals(object1, Object2))
                return true;

  
            if (object1.GetType() != Object2.GetType())
                return false;
            if (Object2.GetType().IsArray && object1.GetType().IsArray)
            {
                dynamic array1 = Object2;
                dynamic array2 = object1;
                bool flag= isarrayequal(array1, array2);
                return flag;
            }
    
            var propertyInfos = Object2.GetType().GetProperties();


            foreach (var propertyInfo in propertyInfos)
            {
                var othersValue = propertyInfo.GetValue(Object2);
                var currentsValue = propertyInfo.GetValue(object1);
                if (othersValue == null && currentsValue == null)
                    continue;

          
                if ((currentsValue is IList && propertyInfo.PropertyType.IsGenericType) ||
                    (othersValue is IList && propertyInfo.PropertyType.IsGenericType))
                {
   
                    dynamic cur = currentsValue;
                    dynamic oth = othersValue;
                    if (cur != null && cur.Count > 0)
                    {
                        var result = false;
                        foreach (object cVal in cur)
                        {
                            foreach (object oVal in oth)
                            {
                                //Recursively call the Equal method
                                var areEqual = equalcomparere(cVal, oVal);
                                if (!areEqual) continue;

                                result = true;
                                break;
                            }

                        }
                        if (result == false)
                            return false;
                    }
                }

                else
                {
                   
                    var curType = currentsValue.GetType();

             
                    if (curType.IsValueType || currentsValue is string)
                    {
                        var areEquals = currentsValue.Equals(othersValue);
                        if (areEquals == false)
                            return false;      
                    }
                    else
                    {

                        var areEqual = equalcomparere(currentsValue, othersValue);
                        if (areEqual == false)
                            return false;
                    }
                }
            }

            return true;
        }
        public bool isarrayequal(dynamic a, dynamic b)
        {
            Dictionary<dynamic, int> table = new Dictionary<dynamic, int>();

            foreach (var data in a)
            {
                if (!table.ContainsKey(data))
                {
                    table.Add(data, 1);
                }
                else
                {
                    table[data]++;
                }
            }
            foreach (var data in b)
            {
                if (!table.ContainsKey(data))
                {
                    table.Add(data, 1);
                }
                else
                {
                    table[data]++;
                }
            }
            foreach (var data in table)
            {
                if (data.Value == 1 || data.Value > 2)
                {
                    return false;
                }
            }
            return true;
        }
    }

    //compare array


    //example class

    class Student {
        public string name { get; set; }
        public int[] marks { get; set; }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Student ajay = new Student();
            ajay.name = "vijay";
            ajay.marks = new[] { 80, 90, 10 };
            Student vijay = new Student();
            vijay.name = "ajay";
            vijay.marks = new[] { 80, 90, 10 };
            Comparator obj = new Comparator();
            bool result = obj.equalcomparere(ajay, vijay);
            Console.ReadLine();


        }
    }
}
