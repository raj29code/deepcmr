﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeepCompare.Interface
{
   public interface ICompare
    {
        bool equalcomparere(object object1, object Object2);
        bool isarrayequal(dynamic object1, dynamic object2);


    }
}
